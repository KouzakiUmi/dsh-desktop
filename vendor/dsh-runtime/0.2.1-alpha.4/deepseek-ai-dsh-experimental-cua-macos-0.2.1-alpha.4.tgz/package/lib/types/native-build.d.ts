import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Architecture names used by the platform-specific native payload. */
export type NativeArchitecture = 'arm64' | 'x64';
/**
 * Validate the host before preparing a platform-specific executable.
 * @param platform - Node host platform.
 * @param architecture - Node host architecture.
 * @returns Supported macOS architecture.
 * @throws When the current host has no native implementation.
 */
export declare function nativeHostArchitecture(platform: string, architecture: string): NativeArchitecture;
/** Explicit compiler ownership and resource limits for one preparation. */
export interface NativeBuildSpec {
    packageRoot: string;
    architecture: NativeArchitecture;
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
}
/**
 * Locate the platform-specific executable owned by the CUA package.
 * @param packageRoot - Directory containing the CUA package manifest.
 * @param architecture - Architecture of the process that will execute the helper.
 * @returns Absolute executable path.
 */
export declare function nativeExecutablePath(packageRoot: string, architecture: NativeArchitecture): string;
/**
 * Recognize the repository-owned package location before allowing local compilation.
 * @param packageRoot - Real directory containing this package.
 * @returns True only for a CUA package in a DSH source checkout.
 */
export declare function isSourcePackage(packageRoot: string): Promise<boolean>;
/**
 * Build the package payload and retain an immutable executable for source-runtime processes.
 * @param spec - Checkout, target, managed process provider and cancellation/deadline limits.
 * @returns Content-addressed runtime path after compilation and complete process cleanup.
 * @throws When compilation, cancellation, resource cleanup or artifact publication fails.
 */
export declare function buildNativeExecutable(spec: NativeBuildSpec): Promise<string>;
/**
 * Prepare source builds on activation; installed packages must already carry their native payload.
 * @param spec - Native preparation inputs for this host.
 * @returns Ready native executable without requiring a compiler for an installed package.
 */
export declare function prepareNativeExecutable(spec: NativeBuildSpec): Promise<string>;
//# sourceMappingURL=native-build.d.ts.map