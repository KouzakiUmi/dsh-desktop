/** Bounded exact-copy evidence and tentative buffering for streamed reasoning. */
/** Deployment-selected detection, buffering, and delayed interruption budgets, in UTF-16 characters. */
export interface ReasoningWatchConfig {
    /** Maximum raw and accepted suffix retained independently. */
    windowChars: number;
    /** Fixed internal observation cadence, independent of provider chunk boundaries. */
    scanChars: number;
    /** Minimum exact repeated extent before subsequent input becomes tentative. */
    holdChars: number;
    /** Minimum exact repeated extent before proven copies can be suppressed. */
    confirmChars: number;
    /** Cumulative suppressed extent before a still-looping call can be interrupted. */
    cancelChars: number;
    /** Unproven text retained before releasing a recovered suffix. */
    recoveryChars: number;
    /** Maximum period searched by the exact-cycle detector. */
    maxPeriodChars: number;
    /** Minimum complete sentence units for reordered-pool evidence. */
    minPoolUnits: number;
    /** Minimum fraction of unit characters belonging to repeated exact units. */
    poolShare: number;
}
/** Accepted text and the local decision after consuming one provider delta. */
export interface ReasoningWatchResult {
    /** Accepted text, including any previously tentative text released by this observation. */
    text: string;
    /** Whether the suppression budget ended this call; no provider finish is fabricated. */
    interrupt: boolean;
}
/**
 * Validate the complete resolved settings before installing a policy.
 * @param config - deployment-selected complete budgets.
 * @throws when a count is invalid or the buffering/confirmation bounds conflict.
 */
export declare function validateReasoningWatchConfig(config: ReasoningWatchConfig): void;
/**
 * Conservatively suppress exact copies only after sustained repetition evidence.
 * Normal text is accepted immediately. Raw and accepted suffixes, pending text,
 * and pending span metadata are bounded by the configured window. This is not a
 * semantic classifier: changed identifiers, numbers, and negations remain new text.
 */
export declare class ReasoningWatch {
    private readonly config;
    private raw;
    private accepted;
    private offset;
    private pending;
    private pendingChars;
    private phase;
    private protected;
    private stopped;
    private omitted;
    constructor(config: ReasoningWatchConfig);
    /** Number of confirmed copy characters omitted so far. */
    get suppressedChars(): number;
    /** Retained character count, excluding output returned to the caller. */
    get retainedChars(): number;
    /**
     * Disable repetition-driven cancellation after a complete protocol tool block.
     * Filtering remains active; the caller must independently bound unfinished tool settlement.
     */
    protectCommit(): void;
    /**
     * Consume one delta; internal observation positions do not depend on delta sizes.
     * @param text - the original reasoning delta, without normalization.
     * @returns accepted text and whether the local suppression budget was exhausted.
     */
    push(text: string): ReasoningWatchResult;
    /**
     * Settle text that a caller withheld at a barrier, together with this watch's
     * own unresolved text. Confirmed copies stay suppressed, and the arrival order
     * of every character is preserved. A settle never starts a cancellation: the
     * observation window for text withheld this long has passed, and a stop that
     * can no longer abort the call would otherwise drop characters the caller
     * still owes its own consumer.
     * @param text - caller-withheld original text in arrival order.
     * @returns accepted text in arrival order, with confirmed copies removed.
     */
    release(text: string): string;
    private consume;
    /**
     * Release only unresolved text at an ordering barrier or final settlement.
     * Confirmed copies have already been removed and can never be released.
     * @returns pending original text in arrival order.
     */
    flush(): string;
    private remember;
    private evidence;
    private suppress;
}
//# sourceMappingURL=reasoning-watch.d.ts.map