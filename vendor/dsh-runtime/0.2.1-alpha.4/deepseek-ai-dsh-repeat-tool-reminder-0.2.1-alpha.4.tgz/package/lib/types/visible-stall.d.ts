/**
 * Adaptive visible-output stall for near-duplicate reasoning. Normal reasoning is
 * released as it arrives; only after one observation qualifies does the stall
 * withhold the following characters, and it either releases them verbatim or
 * discards the withheld suffix when it interrupts. It never rewrites or removes
 * characters it already released.
 */
/** Largest observation window and held suffix this stall may retain, whatever the configuration says. */
export declare const visibleStallRetentionCeiling = 8192;
/** Deployment-selected observation, retention, and confirmation budgets, in UTF-16 characters. */
export interface VisibleStallConfig {
    /** Initial observation window; output is released as it arrives until one observation qualifies. */
    windowChars: number;
    /** Ceiling for the expanding observation window and therefore for the held suffix. */
    maxWindowChars: number;
    /** Observation cadence in observed characters, independent of provider delta boundaries. */
    scanChars: number;
    /** Minimum complete sentence units inside one observation. */
    minUnits: number;
    /** Minimum fraction of units whose trimmed text also occurs elsewhere in the observation. */
    unitShare: number;
    /**
     * Minimum fraction of sentence characters inside recurring sentences. A
     * recurring interjection alone cannot qualify an observation whose content
     * keeps arriving as new sentences, so this is the evidence that recurring
     * sentences carry real mass rather than filler.
     */
    unitCharShare: number;
    /** Length of the exact fragments that measure reused characters. */
    shingleChars: number;
    /** Minimum fraction of observation characters inside a fragment repeated at least `shingleChars * 2` away. */
    shingleShare: number;
    /** Consecutive qualifying observations that confirm repetition and discard the held suffix. */
    confirmWindows: number;
    /** Consecutive non-qualifying observations that release the held suffix verbatim. */
    recoveryWindows: number;
}
/** Defaults materialized by the owning plugin's configuration schema. */
export declare const visibleStallDefaults: VisibleStallConfig;
/**
 * Reject settings that would defeat the bounded, majority-evidence contract.
 * @param config - deployment-selected complete budgets.
 * @throws when a count is not a positive safe integer, the window exceeds
 * {@link visibleStallRetentionCeiling}, or a share is not a majority below one.
 */
export declare function validateVisibleStallConfig(config: VisibleStallConfig): void;
/** One withholding transition this stall made while consuming a character. */
export type VisibleStallStage = 
/** Observation began withholding output to check it. */
'suspected'
/** Observation stopped qualifying, so the withheld output was released. */
 | 'released'
/** A barrier released the withheld output without judging it (fence or explicit flush). */
 | 'barrier';
/** One stall decision for one original character. */
export interface VisibleStallResult {
    /** Original text released now, in arrival order; empty while the stall withholds. */
    text: string;
    /** Whether the held suffix was discarded because repetition was confirmed. */
    interrupt: boolean;
    /** Withholding transition this character caused; absent while the withholding state is unchanged. */
    transition?: VisibleStallStage;
}
/**
 * Stop-only stall over one reasoning block's original characters. Detection uses
 * sentence recurrence in a rolling window plus the fraction of characters
 * inside locally repeated fragments; evidence never rewrites text, and every
 * released character leaves the stall exactly once. Fenced code suspends
 * detection so example scaffolding is not mistaken for repeated prose.
 */
export declare class VisibleStallWatch {
    private readonly config;
    private raw;
    private pendingChars;
    private received;
    private capacity;
    private holding;
    private high;
    private low;
    private stopped;
    private protected;
    private fence;
    private line;
    /** Set only while a fence transition releases, so the release reports its real cause. */
    private releasedByFence;
    constructor(config: VisibleStallConfig);
    /**
     * Characters retained independently of every caller-owned string. The withheld
     * suffix is a suffix of this buffer, so the complete retention is one window.
     */
    get retainedChars(): number;
    /** Current observation window, which expands toward the configured ceiling while withholding. */
    get windowChars(): number;
    /** Characters currently withheld from the caller. */
    get heldChars(): number;
    /**
     * Disable cancellation after a complete protocol tool block. Withholding keeps
     * working; a confirmed observation then releases instead of discarding, because
     * unfinished tool output belongs to the settlement budget, not to this stall.
     */
    protectCommit(): void;
    /**
     * Release every unresolved character at an output barrier or final settlement.
     * @returns withheld original text in arrival order; empty after an interruption, whose suffix is already gone.
     */
    flush(): string;
    /**
     * Consume one original character in arrival order.
     * @param char - exactly one character of unmodified reasoning output.
     * @returns the text released for this character, whether the held suffix was
     * discarded, and the withholding transition this character caused.
     */
    push(char: string): VisibleStallResult;
    /** One character through the detector; `push` adds the withholding transition around it. */
    private step;
    /** Take the withheld suffix out of the observation window, in arrival order. */
    private releaseHeld;
    /** Drop the observation window; a barrier is not evidence about the text after it. */
    private resetObservation;
    /** Whether the current observation shows repeated sentences over reused characters. */
    private qualifies;
    /**
     * Track fenced-code delimiters from the bounded line prefix.
     * @param char - the character just received.
     * @returns `open` or `close` when this character completed a fence line, otherwise `undefined`.
     */
    private scanFenceLine;
}
//# sourceMappingURL=visible-stall.d.ts.map