/** Optional reasoning-copy policy, independent of advisory tool-call reminders. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { AssistantOutputInterruption, AssistantOutputItem, AssistantOutputPolicy } from '@deepseek-ai/dsh-agent';
import { type StreamChunk } from '@deepseek-ai/dsh-llm';
import { type ReasoningWatchConfig } from './reasoning-watch.ts';
import { type VisibleStallConfig } from './visible-stall.ts';
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /**
         * The continuation this guard injects after locally interrupting a
         * reasoning call. It addresses the Step it continues, so a presentation
         * consumer can place and count the recovery without re-deriving either
         * fact from the surrounding window.
         */
        'reasoning-loop-recovery': {
            kind: 'reasoning-loop-recovery';
            /** Turn whose call was interrupted and continued. */
            turn: number;
            /** Step whose call was interrupted and continued. */
            step: number;
            /** One-based ordinal of this recovery among the Turn's recoveries. */
            attempt: number;
            /** Recoveries one Turn may start, as configured on this deployment. */
            limit: number;
        };
    }
}
/** Explicit opt-in settings for editable-plain conversation-model output. */
export interface ReasoningLoopConfig extends ReasoningWatchConfig {
    /**
     * Visible-output stall, or `false` to filter only proven exact copies. A stall
     * holds output that looks repetitive, so `maxWindowChars` bounds the characters
     * withheld from the user and session at any moment.
     */
    visibleStall: false | VisibleStallConfig;
    /** Maximum locally interrupted calls resumed within one turn, including native child agents. */
    maxRecoveries: number;
    /** Post-tool settlement budget: each received event costs one plus its new delta's UTF-16 characters. */
    settlementBudget: number;
}
/** Validated settings; omission at the owning plugin disables this policy entirely. */
export declare const ReasoningLoopConfig: z<ReasoningLoopConfig>;
/** Why the policy ended a call locally. */
type ReasoningStopReason = 'repetition' | 'visible-repetition' | 'settlement-limit';
/**
 * Filter one reasoning block without retaining another complete copy of its text.
 * Interleaved non-reasoning events release unresolved text before passing through.
 * Additional reasoning indexes are observed unchanged; the first remains protected
 * against a full block-end restoring any copies already suppressed.
 */
export declare class ReasoningOutputPolicy implements AssistantOutputPolicy {
    private readonly interrupt;
    /** Whether the owning plugin still authorizes this call's presentation. */
    private readonly enabled;
    private readonly watch;
    private readonly stall;
    private index;
    private closed;
    private localInterruption;
    private settlementLeft;
    private readonly settlementBudget;
    constructor(config: ReasoningLoopConfig, interrupt: (reason: ReasoningStopReason) => AssistantOutputInterruption, 
    /** Whether the owning plugin still authorizes this call's presentation. */
    enabled: () => boolean);
    get interruption(): AssistantOutputInterruption | undefined;
    push(chunk: StreamChunk): readonly AssistantOutputItem[];
    flush(): readonly AssistantOutputItem[];
    /**
     * Gate one delta through the stall, then through exact-copy filtering. The stall
     * sees every original character, so neither detector depends on delta
     * boundaries. Text the stall withholds reaches the exact-copy filter when the
     * stall releases it, and an interruption discards the withheld suffix instead.
     */
    private accept;
    /** Announce each withholding transition this call made; a disposed policy announces nothing. */
    private stageItems;
}
/**
 * Register the optional per-call policy; all listeners and recovery state belong to this fiber.
 * @param ctx - plugin scope, also limiting which Agents receive the policy.
 * @param config - complete resolved settings, validated before registration.
 */
export declare function installReasoningPolicy(ctx: Context, config: ReasoningLoopConfig): void;
export {};
//# sourceMappingURL=reasoning-policy.d.ts.map