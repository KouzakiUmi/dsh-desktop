import type { AssistantRecoveryChatData, AssistantStallStage } from '../contract/chat-nodes.ts';
import type { ChatViewSlotProps } from '../contract/slots.ts';
/** Props for the notice that reports this Step's repetition detection and truncation. */
export interface RecoveryNoticeProps {
    /** Durable facts of the continuation this Step consumed, once it consumed one. */
    recovery?: AssistantRecoveryChatData | undefined;
    /** Failure that cut the running call, reported before its settlement exists. */
    interruption?: {
        readonly message: string;
    } | undefined;
    /** Latest withholding stage the live attempt reported, when it reported one. */
    stall?: AssistantStallStage | undefined;
    /** Whether the call this notice covers is still running. */
    running: boolean;
    /** The owning view's locale seat, passed down as a plain prop. */
    t: ChatViewSlotProps['t'];
}
export declare const RecoveryNotice: import("react").MemoExoticComponent<({ recovery, interruption, stall, running, t, }: RecoveryNoticeProps) => import("react").JSX.Element>;
//# sourceMappingURL=RecoveryNotice.d.ts.map