import type { Context } from '@deepseek-ai/cordis';
import type { AssistantBlock, AssistantMessageNode, ConversationMatch, ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { AssistantChatData, AssistantInterruptionChatData, AssistantRecoveryChatData, AssistantStallStage } from '../contract/chat-nodes.ts';
declare module '../contract/chat-nodes.ts' {
    interface ChatNodeDataMap {
        /** Streaming, settled, or interrupted Assistant step. */
        'assistant-step': AssistantChatData;
    }
}
declare module '@deepseek-ai/dsh-client-ui-conversation/client' {
    interface ConversationStepDataMap {
        /** Streaming, settled, or interrupted Assistant material for this Step. */
        'assistant-step': AssistantChatData;
    }
}
interface AssistantState {
    readonly turn: number;
    readonly step: number;
    readonly blocks: readonly (AssistantBlock | undefined)[];
    readonly visibleBlocks: number;
    readonly firstVisibleSeq: number | undefined;
    readonly firstVisibleTime: number | undefined;
    readonly firstTokenTime: number | undefined;
    readonly final: ConversationMatch | undefined;
    readonly usage: unknown;
    /**
     * Settlements this Step already delivered before the current attempt, oldest
     * first. A locally interrupted call retains its prefix here, so the content a
     * reader already saw survives the attempt that continues it.
     */
    readonly retained: readonly AssistantMessageNode[];
    /** Continuation this Step consumed after a local interruption, when it consumed one. */
    readonly recovery: RecoveryFact | undefined;
    /**
     * Failure that cut the running call before any durable settlement existed.
     * The guard publishes it when it decides, so a stalled provider cleanup
     * cannot leave a reader without the fact that output was truncated.
     */
    readonly interruption: AssistantInterruptionChatData | undefined;
    /**
     * Latest stage the live attempt's repetition detection reported. Live state of
     * this attempt, never durable history: settled Steps and reopened windows
     * derive their row from the durable settlement alone.
     */
    readonly stall: AssistantStallStage | undefined;
}
/** Durable facts of the continuation that resumes a locally interrupted call. */
type RecoveryFact = AssistantRecoveryChatData;
/** Per-step Assistant lifecycle; materialized keys survive cleared stream content as hidden Nodes. */
export declare const assistantDefinition: ConversationNodeDefinition<AssistantState>;
/**
 * Register the Assistant lifecycle business contribution.
 * @param ctx - owning UI Conversation context.
 */
export declare function registerAssistantConversationNode(ctx: Context): void;
export {};
//# sourceMappingURL=assistant.d.ts.map