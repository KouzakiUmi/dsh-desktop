/** Preserve dollar prices without changing upstream math tokens or source positions. */
import type { Extension } from 'micromark-util-types';
/**
 * Reuse dollar math with currency-safe single-dollar closing boundaries.
 * @returns Upstream math grammar with guarded inline dollar constructs.
 * @throws If the installed math extension no longer declares dollar text syntax.
 */
export declare function currencyAwareMath(): Extension;
//# sourceMappingURL=currencyAwareMath.d.ts.map