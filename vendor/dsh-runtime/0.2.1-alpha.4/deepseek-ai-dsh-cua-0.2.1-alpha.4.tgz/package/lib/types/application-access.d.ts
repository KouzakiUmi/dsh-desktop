/** Application consent checked before native observations and input. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { z } from 'zod';
import { type NativeClient } from './native-client.ts';
import type { CuaAppHandle } from './types.ts';
import type { CuaApplicationGrant, CuaApplicationId } from './application-types.ts';
/** Native identity admission occurs before any application observation or input. */
export declare const ApplicationAuthorizationResult: z.ZodObject<{
    id: z.ZodPipe<z.ZodString, z.ZodTransform<CuaApplicationId, string>>;
    name: z.ZodString;
    executablePath: z.ZodString;
    persistable: z.ZodBoolean;
}, z.core.$strip>;
/** Current saved grants and their optional profile writer. */
export interface AccessOptions {
    grants: () => readonly CuaApplicationGrant[];
    save?: ((grants: readonly CuaApplicationGrant[]) => Promise<void>) | undefined;
}
/** Owns application consent and cancels operations when saved access is removed. */
export declare class ApplicationAccess {
    private readonly ctx;
    private readonly options;
    private readonly clients;
    private readonly rejected;
    private readonly active;
    private readonly selections;
    private readonly lifetime;
    private mutationTail;
    private disposal;
    /** @param ctx Host context owning this provider. @param options Live saved grants and profile persistence. */
    constructor(ctx: Context, options: AccessOptions);
    /**
     * Cancel consent waits and join owned operations.
     * @returns Completion after consent waits and active operations settle.
     */
    dispose(): Promise<void>;
    /**
     * Obtain consent for a freshly selected native handle. Free text never grants access.
     * @param agent Exact live task requesting access.
     * @param client Helper that issued the handle.
     * @param handle Helper handle for a running instance or an approved pending launch.
     * @param identity Native executable/signing identity.
     * @param signal Calling tool lifetime.
     * @returns Completion after consent; refusals reject before launch, AX, screenshots, or input.
     */
    select(agent: Agent, client: NativeClient, handle: CuaAppHandle, identity: CuaApplicationGrant & {
        persistable: boolean;
    }, signal: AbortSignal): Promise<void>;
    /**
     * Enforce live consent at the operation that dispatches native work.
     * @param client Helper owning the application handle.
     * @param handle Selected application.
     * @param signal Calling tool lifetime.
     * @param dispatch One native operation, with revocation cancellation.
     * @returns The native result, with no implicit retry after consent or cancellation.
     */
    run<T>(client: NativeClient, handle: CuaAppHandle, signal: AbortSignal, dispatch: (signal: AbortSignal) => Promise<T>): Promise<T>;
    private selectInOrder;
    private withOperation;
    /**
     * Forget the disposed task's transient decisions and selected handles.
     * @param agent Disposed task whose transient decisions are released.
     */
    forget(agent: Agent): void;
    private permitted;
    private denied;
    private reject;
    private invalidate;
    private reconcile;
    private persist;
    private mutate;
}
//# sourceMappingURL=application-access.d.ts.map