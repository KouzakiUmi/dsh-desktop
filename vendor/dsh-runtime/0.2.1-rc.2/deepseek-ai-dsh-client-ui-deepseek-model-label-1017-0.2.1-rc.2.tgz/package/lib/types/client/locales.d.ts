/** Localized label of the fixed release marker. */
/** Simplified Chinese badge copy. */
export declare const zh: {
    'badge.label': string;
};
/** Keys owned by the release-label namespace. */
export type LabelKey = keyof typeof zh;
/** English badge copy. */
export declare const en: Record<LabelKey, string>;
//# sourceMappingURL=locales.d.ts.map