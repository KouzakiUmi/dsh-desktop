/** Sentence-unit scanning shared by the exact-copy pool and the visible-stall metric. */
/** Sentence terminators shared by every sentence-unit metric. */
export declare const UNIT_PATTERN: RegExp;
/** Whether a code unit is a sentence terminator. */
export declare function isSentenceTerminator(code: number): boolean;
/**
 * Count sentence terminators without running the backtracking-prone unit
 * pattern. Every unit produced by {@link UNIT_PATTERN} ends with at least one
 * terminator, so a window with fewer terminators than a threshold cannot reach
 * that many units.
 * @param text - candidate window.
 * @returns terminator count, never negative.
 */
export declare function countTerminators(text: string): number;
/** Whitespace and line terminators that `String.prototype.trim` removes. */
export declare function isTrimBlank(code: number): boolean;
/**
 * Whether a trailing window can carry periodic evidence: at least two non-blank
 * code points and two distinct code points, tested without allocating a slice or
 * a Set. Equivalent to `pattern.trim().length >= 2 && new Set(pattern).size >= 2`.
 * @param raw - the retained window.
 * @param period - trailing length to inspect.
 * @returns whether the trailing window can serve as a periodic pattern.
 */
export declare function patternIsInformative(raw: string, period: number): boolean;
//# sourceMappingURL=sentence-units.d.ts.map