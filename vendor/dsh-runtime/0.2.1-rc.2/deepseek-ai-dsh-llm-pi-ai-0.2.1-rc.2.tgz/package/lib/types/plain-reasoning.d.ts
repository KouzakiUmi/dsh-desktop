/** Explicit plain-reasoning replay for the verified Chat Completions conversion path. */
import type { AssistantMessage, Api, Model } from '@earendil-works/pi-ai';
/**
 * Reject opaque metadata before an explicitly plain route can persist or replay it.
 * The three permitted strings are upstream Chat Completions field selectors,
 * not provider signatures. Empty, encrypted, structured, and tool signatures
 * cannot be silently removed to make an incompatible response look editable.
 * @param message - native response or reconstructed native assistant history.
 */
export declare function assertPlainReasoning(message: AssistantMessage): void;
/**
 * Reconstruct same-route plain history without the implicit foreign-history fallback.
 * Reasoning-only prefixes become assistant text containing exactly those reasoning
 * bytes: upstream Chat Completions otherwise drops a message with no body or tools.
 * Normal responses with text/tools retain their original reasoning-field selector.
 * @param native - history reconstructed from durable content and validated replay metadata.
 * @param target - exact snapshot-bound Chat Completions model.
 * @returns native assistant history with no opaque signatures.
 */
export declare function plainAssistant(native: AssistantMessage, target: Model<Api>): AssistantMessage;
//# sourceMappingURL=plain-reasoning.d.ts.map